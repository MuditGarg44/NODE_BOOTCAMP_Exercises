import React, { Component } from 'react';
// import './App.css';
import "./style.css"
import axios from "axios";
import Header from "./components/Header/Header"
import Studentlist from "./components/students/studentlist";
import StudentHeader from "./components/studentHeader/studentheader"
import SearchBar from "./components/SearchBar/Searchbar"
import {
  BrowserRouter as Router,
  Link,
  Route,
  Redirect
} from "react-router-dom";
import Aboutus from "./components/Header/About_Us";
import Contact from "./components/Header/Contact";
import Home from "./components/Header/Home";

class App extends Component {
  constructor() {
    super();
    this.state = { studentdata: [], filter: "all" };


    axios.get('http://localhost:9000/')
      .then((response) => {
        this.setState({
          studentdata: response.data
        });
        console.log(response.status);
      });
  }



  handleClick = (event) => {
    this.setState({
      filter: event.target.name
    })
  }
  render() {

    // console.log("------------",this.state);
    let { studentdata, filter } = this.state;
    // console.log("11111>>>>", studentdata,filter);
    let studentToRender;
    if (filter === "all") {
      studentToRender = studentdata;
    }
    else {
      console.log(this.state);
      studentToRender = studentdata.filter(item => item.branch === filter)
    }
    return (
      <div className="App">
        <Router>  

          <Header />
        
        
          <Route
            exact
            path="/"
            render={() => <Home />} />
          <Route
            path="/about"
            render={() => <Aboutus />} />
          <Route

            path="/contact"
            render={() => <Contact />} />
        </Router>
        <ul className="filter-button-groups">
          <li>
            <button type="button" name="all" onClick={this.handleClick}>All</button>

          </li>
          <li>
            <button type="button" name="mca" onClick={this.handleClick}>MCA</button>

          </li>
          <li>
            <button type="button" name="btech" onClick={this.handleClick}>BTECH</button>
          </li>
        </ul>

        {console.log(this.state.studentdata)}
        <StudentHeader />
        {studentToRender.map((item, i) => <Studentlist student={item} key={i} filter={this.state.filter} />)}


        <div>
          <SearchBar search={studentToRender} />
        </div>

        

      </div>
    );
  }
}

export default App;
