import React, { Component } from 'react';
// import "./studentlist.css"

export default class Studentlist extends Component
{
    render() {
       const {student,filter} = this.props;
        console.log(this.props);
       
        return (
            <div>
                <ul className="list">
                    <li>
                        {student.firstname}
                    </li>
                    <li>
                        {student.lastname}
                    </li>
                    <li>
                        {student.branch}
                    </li>
                </ul>
            </div>
        );
    }
}