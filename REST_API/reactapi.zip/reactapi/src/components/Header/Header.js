import React, { Component } from 'react';
import {Link} from "react-router-dom";
// import "./Header.css"

export default class Header extends Component
{
    render() {
        console.log(this.props);
        return (
        <section>
             <ul className="mainHeader">
                <li>
                    <Link className="link" to="/">
                    HOME </Link>
                </li>
                <li> <Link className="link" to="/about">
                    ABOUT US </Link>
                </li>
                <li> <Link className="link" to="contact">
                    CONTACT US </Link>
                </li >
             </ul>
               
             </section>
        );
    }
}