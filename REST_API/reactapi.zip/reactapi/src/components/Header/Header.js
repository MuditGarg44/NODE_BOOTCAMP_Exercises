import React, { Component } from 'react';
import Renderedpage from "./renderedpage"
// import "./Header.css"

export default class Header extends Component
{
    render() {
        console.log(this.props);
        return (
        <section>
             <ul className="mainHeader">
                <li onClick={()=>this.props.menuClick("home")} >
                    HOME
                </li>
                <li onClick={()=>this.props.menuClick("about")}> 
                    ABOUT US
                </li>
                <li onClick={()=>this.props.menuClick("contact")}>
                    CONTACT US
                </li >
             </ul>
                <Renderedpage page={this.props.page}/>
             </section>
        );
    }
}