import React, { Component } from 'react';

export default class Renderedpage extends Component{
    render() {
        return (
             <div>
                 {this.props.page}
             </div>
        );
    }
}