import React, { Component } from 'react';

export default class Contact extends Component
{
    render() {
        return (
             <h1> this is contact us page</h1>
        );
    }
}