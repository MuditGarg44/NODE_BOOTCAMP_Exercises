import React, { Component } from 'react';
// import "./studentheader.css"

export default class StudentHeader extends Component
{
    render() {

       
        return (
            <div>
                <ul className="headerlist">
                    <li>
                        First Name
                    </li>
                    <li>
                        Last Name
                    </li>
                    <li>
                        Branch
                    </li>
                </ul>
            </div>
        );
    }
}