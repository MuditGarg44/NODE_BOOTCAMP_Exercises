import React, { Component } from 'react';
// import "./Searchbar.css"
import axios from "axios";

export default class SearchBar extends Component {
    constructor() {
        super();
        this.state = {
            item: "",
            
        }
    }

    componentDidMount() {
        document.getElementById("box").style.display = "none";
    }
    componentDidUpdate()
    {
        if(this.state.item.length <3)
        {
            document.getElementById("box").style.display = "none";

        }

    }

    handleChange = (event) => {
        this.setState({
            item: event.target.value
        });
    }
    render() {

        let item = this.state.item;

        if (item.length > 2) {
            document.getElementById("box").style.display = "block";
    
            var results = this.props.search.filter(name=> name.firstname.startsWith(item));
        }
        
        return (
            <section>
                <input type="text" name="search" onChange={this.handleChange} placeholder="Enter name to search" className="searchName" />
                {console.log("results inside dom >>>>>>>>" , results)}

                <div className="box" id="box"><p>{Array.isArray(results) ? results.length ===0? "no results" : results[0].firstname  :"no results"}</p></div>
            </section>
        );
    }

}