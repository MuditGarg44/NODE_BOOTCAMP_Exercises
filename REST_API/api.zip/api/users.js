module.exports = [{username:"xxnagato",password:"admin",firstname:"nagato", lastname:"uzumaki", branch:"hidden_rain"},
                  {username:"xxkonan" ,password:"admin", firstname:"konan", lastname:"n/a", branch:"hidden_rain" },
                  {username:"xxyahiko" ,password:"admin", firstname:"yahiko", lastname:"n/a", branch:"hidden_rain"}];