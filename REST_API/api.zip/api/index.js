const fs = require('fs');
const http = require('http');
const url = require('url');
const port = 9000;
const hostname = '127.0.0.1';
const userdata = require('./students');



showuser = (path,res)=>
{
    let queryString = path.query;

    console.log(" \n query string is " + JSON.stringify(queryString) + "\n");
    res.setHeader("Content-Type", 'application/json');
    res.setHeader('Access-Control-Allow-Origin','*');
    res.setHeader('Access-Control-Allow-Headers',"*");
    let found = userdata.find(item=>item.firstname===queryString.firstname?res.end(JSON.stringify(item)):0);
    if(!found)
    {
        res.end(JSON.stringify(userdata));
    }
    
}
showheader = (path,res) =>
{
    fs.readFile(path, (error, data) => {
		if(error){
			res.writeHead(400);
			res.write("file not found");
		} else {
            res.setHeader('Access-Control-Allow-Origin','*');
            res.setHeader('Access-Control-Allow-Headers',"*");
			res.writeHead(200, {'Content-Type': 'text/html'} );
			res.write(data);
		}

		res.end();
	});

}


var server = http.createServer((req,res)=> {
    let pathobj = url.parse(req.url,true);
    
    switch(pathobj.pathname)
    {
        case '/': showuser(pathobj,res);
        break;
        case '/home' : showheader('./files/home.html',res);
        break;
        case '/about' : showheader("./files/about.html",res);
        break;
        case '/contact' : showheader("./files/contact.html",res);
        break;
        default : break;
    }
})

server.listen(port,hostname,() =>{
	console.log(`Server running at http://${hostname}:${port}/`);
});