module.exports = [{firstname:"itachi", lastname:"uchiha", branch:"mca"},
                  {firstname:"kisame", lastname:"hoshikage", branch:"mca"},
                  {firstname:"obito", lastname:"uchiha", branch:"mca"},
                  {firstname:"madara", lastname:"uchiha", branch:"btech"},
                  {firstname:"hashirama", lastname:"senzu", branch:"btech"},
                  {firstname:"tobirama", lastname:"senzu", branch:"btech"}];