import React, { Component } from 'react';
import "../../css/style.css"
import axios from "axios";

export default class Dashboard extends Component{
    constructor(props)
    {
        super(props)
        console.log(this.props)
    }
    componentDidMount()
    {
        axios.get("http://localhost:9000/dashboard")
        console.log(localStorage.getItem('user'))
        if(!localStorage.getItem('user'))
        {
            this.props.history.push("/login");
        }
    }
    render() {
        return (
             <div> This should run only after authentication</div>
        );
    }
}