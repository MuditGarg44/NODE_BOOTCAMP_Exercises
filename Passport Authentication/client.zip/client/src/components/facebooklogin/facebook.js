import React, { Component } from 'react';
import "../../css/style.css"

export default class Facebook extends Component{
    constructor(props){
        super(props)
        this.state = {
            username : "",
            password : ""
        }
    }
    handleChange=(event)=>{
        this.setState({
            [event.target.name] : event.target.value
        })
    }
    render() {
        return (
             <section className="fbsection">
                <p className="fbheader">Facebook Login</p>
                <input type="text" name="username" className="fbusertext" value={this.state.username} placeholder="Username" onChange={this.handleChange} />
                <input type="password" name="password" className="fbpassword" value={this.state.password} placeholder="Password" onChange={this.handleChange} />
                <input type="submit" value="sbmit" className="fbsubmit"/>
             </section>
        );
    }
}