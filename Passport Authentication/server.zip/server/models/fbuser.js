const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const crypto = require("crypto");


let FbusersSchema = new Schema({
    name : String,
    email : String,
    password : String,
    salt : String

});

FbusersSchema.pre('save',function(next){
    this.salt = crypto.randomBytes(16).toString('hex');

    this.password = crypto.pbkdf2Sync(this.password, this.salt, 10000, 512, 'sha512').toString('hex');
    next();
});

module.exports = mongoose.model("Fbuser" , FbusersSchema);