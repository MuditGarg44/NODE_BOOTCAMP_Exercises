module.exports = (app) => {
    const Users = require("../models/users.js");
    const Fbuser = require("../models/fbuser")
    const bodyparser = require("body-parser");
    const passport = require("passport")
    const cookieparser = require("cookie-parser");
    var session = require("express-session")
    const LocalStrategy = require("passport-local");
    const FacebookStrategy = require("passport-facebook");
    const cors = require("cors");

    app.use(cors());



    app.use(bodyparser.urlencoded({extended : false}));
    app.use(bodyparser.json());

    app.use(cookieparser());
    app.use(session({ 
        secret: 'something', 
        cookie: { 
            secure: false
        }}))

    app.use(function (req, res, next) {
        res.header("Access-Control-Allow-Origin", "*");
        res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
        res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
        next();
    });
    app.use(passport.initialize());
    app.use(passport.session());



    passport.use(new LocalStrategy(function(username,password,done){
        Users.findOne( {name : username})
        .then(user=>{
            // return next(null, false, { message: 'Incorrect username.' })
            if(!user){
                return done('Incorrect username.');
            }
            if(!user.validatePassword(password)){
                return done('Incorrect password.');
            }
            return done(null, user);
        })
        .catch(err=> {
            return done(err);
        });
    }));
    passport.use(new FacebookStrategy({
        clientID: "1250653701764676",
        clientSecret: "76dc9753941e549d3f696dddc5675f70",
        callbackURL: 'http://localhost:9000/facebook/callback',
        profileFields: ["id", "email", "name"]

    },
    function(accessToken, refreshToken, profile, done) {
      
        const { email, last_name, first_name } = profile._json;
        const tempUser = {
            name: `${first_name} ${last_name}`,
            email,
            password: "NA"
        };
        Fbuser.findOne({email:email})
        .then(res => {
            if (!res) {
                let newUser = Fbuser({
                    name: tempUser.name,
                    email: tempUser.email,
                    password: tempUser.password
                    
                });
            
                 newUser.save()
            }
        })
        .then(res => {
            done(null, tempUser);
        })
        .catch(err => {
            console.log("internal errror", err);
        });
    }));



    passport.serializeUser(function(user,cb){
        console.log("Serializing user called with");
        cb(null, user);
    
    });
    passport.deserializeUser((user, cb) => {
        console.log("deserialize called");
        cb(null, user);
      });

    app.post("/adduser", (req,res)=>{
        let newuser = new Users({name : req.body.username});
        newuser.setPassword(req.body.password);
 
        newuser.save()
        .then(result=>{
            res.send(result);
        })
        .catch(err=>{
            res.send({
                isSuccess : false,
                err,
            });
        })
    })

    app.post("/login", passport.authenticate("local"), (req,res)=>{
        if(req.user) {

            res.end(JSON.stringify({
                isSuccess : true, 
                message: "User Authenticated",
                user : req.user
            }))
        }

        }
     );
    //  app.get("/fakeroute" , (req,res)=>{
    //      console.log("hit made at fake route")
    //      res.redirect("/facebookLogin");
    //  });
    app.get("/facebookLogin", passport.authenticate("facebook", { scope: ["email"] }),
        (req, res, next) => {
            
        res.end();
    });

    app.get( "/facebook/callback",
        passport.authenticate("facebook"),
        (req, res) => {
            console.log("does this runs?")
            res.send(res.req.user);
        });


    Authenticated = (req,res,next)=>{
        if(req.isAuthenticated())
        {
           return next();
        }
        else
        {
            console.log("inside else")
            console.log(req.sessionStore.sessions, "~~~~~")
            console.log(req.session);
            res.send({
                isAuth : false
            });
        }
    }

    app.get("/dashboard", Authenticated, (req,res)=>{

            console.log(req.user , "<<<<<<<<<")
            // res.send("trying to find req.user")
            res.end({
                isAuth : true
            });
        
    });
}