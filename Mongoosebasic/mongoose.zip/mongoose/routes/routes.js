module.exports = (app) =>{
// const router = require('express').Router();
const Todo = require('../models/todo');

const bodyparser = require("body-parser");
app.use(bodyparser.urlencoded({extended : false}));
app.use(bodyparser.json());

 app.use(function (req, res, next) {
        res.header("Access-Control-Allow-Origin", "*");
        res.header("Access-Control-Allow-Methods", "*");
        res.header("Access-Control-Allow-Headers", "*");
        next();
    });

app.get('/', (req,res) => {
    Todo.find({}).then((results)=>{
        // console.log(results);
        res.send(JSON.stringify(results));
    })
});

app.post('/todos', (req,res)=>{
    let newtodo = new Todo({description : req.body.desc});

    newtodo.save().then((result)=> {
        res.redirect('/');

    }).catch((err)=>{
        console.log("error in saving data");

    })
});
app.delete('/todos/:id', (req,res)=>{ 
    console.log("inside delete method", req.params.id);
    
    Todo.findOneAndDelete({_id : req.params.id} , (err,result)=>{
        if(err)
        {
            console("deletion failed");
        }
        console.log("response running?");

        res.send(JSON.stringify({
                    isSuccess: true,
                    message:"Deleted Successfuly"
                }));
    });
    // .then(res => {
    //     console.log("respons is running");
    //     res.json({
    //         isSuccess: true,
    //         message:"Item Deleted"
    //     });
    // })
    // .catch(err => {
    //     console.log("err is running");
    //     res.json({
    //         isSuccess: false,
    //         message:err
    //     });
    // });
    


    });

}