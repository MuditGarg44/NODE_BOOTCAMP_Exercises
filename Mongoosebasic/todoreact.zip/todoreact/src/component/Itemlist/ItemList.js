import React, { Component } from 'react';
import './Itemlist.css';

class Itemlist extends Component
{
    constructor()
    {
        super();
        
    }
    render() {
        console.log(this.props , " ----------------")
        return (
             <div className="itemstyle">
                <div>{this.props.item.description}</div>
                <div className="Cross" onClick={()=>this.props.delete(this.props.item._id)}> X </div>
                 
             </div>
        )
    }
}
export default Itemlist;