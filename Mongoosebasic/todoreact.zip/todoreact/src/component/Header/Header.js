import React, { Component } from 'react';
import {Link} from 'react-router-dom';
import './Header.css';

class Header extends Component
{
    render() {
        let isAuth = this.props.isAuth;
        return (
             <header>
                 <h1>Live Session</h1>
                <div>
                    {isAuth?<Link to="/logout"  className="loginlink">Logout</Link>:<Link to="/login"  className="loginlink">Login</Link>}
                    
                </div>
             </header>
        );
    }
}
export default Header;