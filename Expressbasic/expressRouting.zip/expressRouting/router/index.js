module.exports = (app,path) =>
{
    const bodyparser = require("body-parser");
    app.use(bodyparser.urlencoded({extended : false}));
    app.use(bodyparser.json());
    app.use(function (req, res, next) {
        res.header("Access-Control-Allow-Origin", "*");
        res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
        res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
        next();
    });
    let student = require("../data/student");
    // app.use("/students", (req,res,next) => {
    //     if(req.method == 'post')
    //     {
    //         console.log("if condition runs");

    //     }
    //     else
    //     {
    //         console.log("else runs");
    //     }
    //     next();
    // })

    // app.get('/', (req,res)=>
    // {
    //     res.sendFile('index.html', {root : path.join('__dirname','../views/')});
    // })
    // app.get('/about', (req,res)=>
    // {
    //     res.sendFile('about.html', {root : path.join('__dirname','../views/')});
    // })
    app.get('/students', (req,res)=>{
        res.send(JSON.stringify(student));
        
    }).delete('/students/:id', (req,res)=>{
        student = student.filter(item => item.ID !== req.params.id);
        res.send(JSON.stringify(student));
    }).post('/students', (req,res, next)=>{
        res.setHeader('Content-Type' , 'application/json')
        let date = new Date();
        let newstudent = {
            ID : req.body.studentId,
            Name : req.body.name,
            Class : req.body.class,
            Created_At : date
        }
        let exists = student.find(item => item.ID === newstudent.ID? 1:0)
        if(exists)
        {
            res.status(404)
                .send("ID should be unique");  
        }
        else
        {
            student.push(newstudent);
            res.status(200).send(JSON.stringify({ message: "Student Added Succesfully"}));
        }
        next();


    })
}