const express = require('express');
const port = 9000;
const app = express();
const path = require('path');

const router = require("./router/index");

router(app,path);

app.listen(port, ()=>{
    console.log(`Server running at https://localost:${port}`);
})