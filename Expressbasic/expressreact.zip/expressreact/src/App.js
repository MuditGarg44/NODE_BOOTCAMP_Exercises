import React, { Component } from 'react';
import logo from './logo.svg';
// import './App.css';
import "./style/style.css"
import Student from "./components/student/student.js"
import Newstudent from "./components/NewStudent/newstudent"
import Header from "./components/Header/Header"
import About from "./components/About/About"
import {
  BrowserRouter as Router,
  Route,
  Link,
  Redirect
} from "react-router-dom";
import Axios from 'axios';


class App extends Component {
  constructor(props) {
    
    
    super(props);
    // console.log(this.props);
    this.state = {
      empty : ""
    }  
  }

  

  render() {
    return (
      <div className="App">
      <Router>
        <Header/>
        <Route
          exact
          path="/"
          component= {Student}
        />
        <Route 
          path="/addstudent"
          // component= {Newstudent}
          render={(props)=><Newstudent {...props}/>}
        />
        <Route 
          path="/about"
          render={()=><About/>}
        />


        
      </Router>
          
      </div>
    );
  }
}

export default App;
