import React, { Component } from 'react';
import "../../style/style.css"

export default class Studentlist extends Component
{
    render() {
        let student = this.props.students;

        return (
             <ul className="list">
                <li>
                    {student.ID}
                </li>
                <li>
                    {student.Name}
                </li>
                <li>
                    {student.Class}
                </li>
                <li>
                    <span onClick={()=>this.props.delete(student.ID)}>
                <i className="fas fa-trash-alt"></i> </span>
                </li>
             </ul>
        );
    }
}