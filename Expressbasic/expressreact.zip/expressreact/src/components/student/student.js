import React, { Component } from 'react';
import axios from "axios";
import Studentlist from "./studentlist"
import "../../style/style.css"

export default class Student extends Component
{
    constructor(props)
    {
        super(props);
        console.log(this.props);
        
        this.state = {
            students: []
        }

        axios.get("http://localhost:9000/students").then(response=>{
            this.setState({
                students : response.data
            
            });
        } );
    }
    delete = (id) =>{
        axios.delete("http://localhost:9000/students/" +id).then(response =>{
            this.setState({
                students : response.data
            
            });
        } ); 
        

    }

    render() {
        let {students} = this.state;
        console.log(students, "<<<<<<<state");
        return (
            <section>
             <ul className="StudentHeader">
                <li>
                    ID
                </li>
                <li>
                    NAME
                </li>
                <li>
                    CLASS
                </li>
                <li>
                    &nbsp;
                </li>
             </ul>
             {students.map((item , i)=> <Studentlist students={item} key={i} delete={this.delete}/>)}
             </section>
        );
    }
}