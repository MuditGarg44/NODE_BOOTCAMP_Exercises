import React, { Component } from 'react';
import "../../style/style.css"
import Axios from "axios";

export default class Newstudent extends Component
{
    constructor(props)
    {
        super(props)
        this.state = {
            studentId : "",
            name : "",
            class : ""
        };
    }

    handleChange = (event) =>
    {
        this.setState({
            [event.target.name] : event.target.value
        })
    }
    handleSubmit = (event,data) =>
  {
    event.preventDefault();
    Axios.post("http://localhost:9000/students" , data)
    .then(response=> 
        document.getElementById("messagediv").innerHTML= response.data.message)
        .then(()=> setTimeout( function() {this.props.history.push("/")}.bind(this),3000 ))
    .catch(err => {
        debugger;
        console.log(err);
        document.getElementById("messagediv").innerHTML = err.response.data;
    })
  }

    render() {
        return (
             <section className="newUserSection">
             <form onSubmit={(event)=>this.handleSubmit(event,this.state)}>
                <h1> ADD New Student </h1>
                <div>
                    <input type="text" name="studentId" placeholder="Enter ID" value={this.state.studentId} onChange={this.handleChange} required/>
                </div>
                <div>
                    <input type="text" name="name" placeholder="Enter Name"  value={this.state.name} onChange={this.handleChange} required/>
                </div>
                <div>
                    <input type="text" name="class" placeholder="Enter Class"  value={this.state.class} onChange={this.handleChange} required/>
                </div>
                <div id="messagediv">

                </div>
                <div>
                    <input type="submit" value="Submit"/>
                </div>
             </form>
             </section>
        );
    }
}