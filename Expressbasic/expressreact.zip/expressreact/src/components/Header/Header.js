import React, { Component } from 'react';
import "../../style/style.css"
import {Link} from "react-router-dom";

export default class Header extends Component
{
    render() {
        console.log(this.props);
        return (
        <section>
             <ul className="mainHeader">
                <li>
                    <Link className="link" to="/">
                    HOME </Link>
                </li>
                <li> <Link className="link" to="/about">
                    ABOUT US </Link>
                </li>
                <li> <Link className="link" to="/addstudent">
                    ADD STUDENT </Link>
                </li >
             </ul>
               
             </section>
        );
    }
}