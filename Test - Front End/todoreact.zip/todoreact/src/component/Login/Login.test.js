import React, { Component } from 'react';
import renderer from "react-test-renderer"
import Login from "./Login"
import Enzyme from "enzyme"
import Adapter from "enzyme-adapter-react-16"
import { shallow,mount } from "enzyme";

Enzyme.configure({ adapter: new Adapter() });

describe("testing login component", () => {
  test("Is snapshot Same", () => {
    const tree = renderer.create(<Login />).toJSON();
    expect(tree).toMatchSnapshot();
  });

  test("is login component rendered and how many fields with className usertxt exists", () => {
    const wrapper = shallow(<Login />);
    expect(wrapper.find(".usertxt").length).toBe(1);
  });

  test("are both text fields rendered",()=>{
    const wrapper=mount(<Login/>);
   
    expect(wrapper.containsMatchingElement(<input name="password"/>)).toEqual(true);
    expect(wrapper.containsMatchingElement(<input name="username"/>)).toEqual(true);

  
})

});