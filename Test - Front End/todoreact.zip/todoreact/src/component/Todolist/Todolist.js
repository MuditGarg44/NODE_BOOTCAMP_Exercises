import React, { Component } from 'react';
import Itemlist from '../Itemlist/ItemList';
import './Todolist.css';
import axios from "axios"

class Todolist extends Component {
    constructor() {
        super()
        this.state = {
            items: [],
            newitem: ""
        }

        axios.get("http://localhost:9000/").then(response => {
            this.setState({
                items: response.data
            })
        })
    }
    handleChange = (event) => {
        this.setState({
            [event.target.name]: event.target.value
        });


    }
    handleClick = () => {
        const obj = { desc: "" };
        obj.desc = this.state.newitem;
        // itemlist.push(obj);
        console.log(obj, "<<<itemlist")
        axios.post("http://localhost:9000/todos", obj)
            .then(response => this.setState({
                items: response.data,
                newitem: ""
            }));
    }

    delete = (id) => {
        console.log(id);
        axios.delete("http://localhost:9000/todos/" + id)
            .then(res => {
                if (res.data.isSuccess === true) {
                    axios.get("http://localhost:9000/").then(response => {
                        this.setState({
                            items: response.data,
                            newitem: ""
                        })
                    })
                }
                // console.log('then' +JSON.stringify(response));
            }).catch(err => {
                console.log('err' + JSON.stringify(err));
            });
    }



    render() {
        console.log(this.state.items, " <<<<< state");
        return (
            <section className="todobg">
                <h1> Things to do : </h1>
                <input type="text" className="itemtxt" onChange={this.handleChange} value={this.state.newitem} name="newitem" />
                <button type="button" onClick={this.handleClick} className="addbtn"> Add </button>
                <ul>
                    {this.state.items.map((item, i) => <li ><Itemlist  item={item} delete={this.delete} /> </li>)}
                </ul>

            </section>
        );
    }
}
export default Todolist;