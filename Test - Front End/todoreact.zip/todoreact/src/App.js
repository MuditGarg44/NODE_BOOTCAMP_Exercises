import React, { Component } from 'react';
import Login from './component/Login/Login.js';
import Home from './component/Home/Home';
import Header from './component/Header/Header';
import Logout from './component/Logout/Logout';
import Todolist from './component/Todolist/Todolist';
import logo from './logo.svg';
import './App.css';
import {
  BrowserRouter as Router,
  Route,
  Redirect,
  Link
} from 'react-router-dom';


class App extends Component {
  constructor(props)
  {
    super(props);
    this.state = {
      username: "admin",
      password: "admin",
      isAuth: false
    }
  }

  toggleAuth = () =>
  {
    // console.log("toggle runs");
    this.setState({
      isAuth: !this.state.isAuth
    });
  }

  handleSubmit = (event,data) =>
  {
    event.preventDefault();
    if (this.state.username === data.username && this.state.password === data.password )
    {
      this.setState({
        isAuth: true
      });
    } else {
      this.setState({
        isAuth: false
      });
    }
    // console.log("runs");
    // console.log(this.state.isAuth);
  }
  render() {
    const {username,password,isAuth} = this.state;
    return (
      <div className="App">
        
        <Router>
          <Header isAuth={isAuth} />
          <Route
            exact
            path="/"
            component={Home}
          />
          <Route
            path="/login"
            render={()=> <Login handleSubmit={this.handleSubmit} isAuth={isAuth}/>}
          />  
          <Route 
            path="/logout"
            render={()=> <Logout isAuth={isAuth} toggleAuth={this.toggleAuth}/>}
            />      
          <PrivateRoute
            path="/todolist"
            isAuth={this.state.isAuth}
            component={Todolist}
          />

        </Router>
      </div>
    );
  }
}

export default App;

const PrivateRoute = ({ component: Component,isAuth, ...rest }) => (
  <Route {...rest} render={props => (
    isAuth ? (
      <Component {...props} />
    ) : (
      <Redirect to={{
        pathname: '/login',
        state: { from: props.location }
      }}/>
    )
  )}/>
)
