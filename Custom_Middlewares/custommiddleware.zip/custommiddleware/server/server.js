const express = require("express");
const app = express();
const routes = require("./routes/index");
const port = 9000;

routes(app);


app.listen(port, ()=> {
    console.log(`Server running at https://localhost:${port}`);
})
