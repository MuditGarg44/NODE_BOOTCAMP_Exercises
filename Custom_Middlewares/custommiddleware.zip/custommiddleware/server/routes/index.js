module.exports =  (app)=>
    {
        let fs = require("fs");
        var {execFile} = require("child_process");

        const user = require("./data/user");
        const bodyparser = require("body-parser");
        const session = require("express-session");
        const uuid = require("uuid/v4");

        app.use((req,res,next)=>{
            res.header("Access-Control-Allow-Origin","*");
            res.header("Access-Control-Allow-Methods","GET,PUT,POST,DELETE");
            res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
            next();
        })

        
        app.use(bodyparser.urlencoded({extended : false}));
        app.use(bodyparser.json());

//-------------------User Authentication-------------------------------------------
       
            app.use(session({
                
                secret :  "shinra tensei",
                resave : false,
                saveUninitialized : true 
            }));

           
        authenticateUser = (req,res,next)=> {
            if(user.username === req.body.username && user.password === req.body.password)
            {
                next(); 
                //next();
            }
            else
           next(res.status(405).send(JSON.stringify({
            isSuccess : false,
            message : "failed"
        })));
        }

        const fnc = (req,res)=>{
            res.send(JSON.stringify({
                isSuccess : true,
                message : "Success",
                session : req.sessionID
            }));
        }
        // ~~~~~~~~Right after login authentication, a get method from github
        // ~~~~~~~~is called from client side which is a question given in assignment
        //~~~~~~~~~(use get method to receieve no. of followers from a github profile using async await)
        app.post("/login", authenticateUser, fnc);


//=========== Example for Streams and Pipe =================================

        let readStream = fs.createReadStream( __dirname+ "/data/fileRead.txt");
        let writeStream = fs. createWriteStream(__dirname+"/data/fileWrite.txt");

        let usePipe = () =>
        {
            //data from fileRead.txt is written to fileWrite.txt
            //data of fileRead.txt can be altered and validate its output
            readStream.pipe(writeStream);
        }
        usePipe();

//========== Example for buffer =======================================

        const buff = Buffer.alloc(10, 'greaterThan10OrNot?????');

        printbuf = () =>{
            console.log(buff.toString());
        }
        printbuf();

//==============child_process execFile function=========================

        execFile('ls', (error, stdout, stderr) => {
            if (error) {
              throw error;
              console.log(error)
            }
            console.log("printing list of files \n",stdout);
          });
    }
