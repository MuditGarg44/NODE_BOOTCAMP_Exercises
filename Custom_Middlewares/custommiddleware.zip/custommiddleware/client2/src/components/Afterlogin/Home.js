import React, { Component } from 'react';
import "../../css/style.css"
import axios from "axios"

export default class Home extends Component{
    constructor(props)
    {
        super(props)
    }
    async componentDidMount()
    {
        try{
            const res = await axios.get("https://api.github.com/users/manoj-nama");
            document.getElementById("number").innerHTML = res.data.followers;
        }
        catch(error)
        {
            document.getElementById("number").innerHTML = error;
        }
        
    }
    render() {
        return (
             <div>
                 <div className="list" >No. of followers on this github profile = <span id="number"> </span></div>
             </div>
        );
    }
}