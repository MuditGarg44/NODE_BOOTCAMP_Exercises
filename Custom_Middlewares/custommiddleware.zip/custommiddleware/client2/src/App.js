import React, { Component } from 'react';
import {
  BrowserRouter as Router,
  Route
} from "react-router-dom";
import Login from "./components/Login/Login"
// import axios from "axios";
import "./css/style.css"
import Home from "./components/Afterlogin/Home"


class App extends Component{
  

  render() {
    return (
      <div className="App">
      <Router>
        <Route
          exact
          path="/"
          render={(props)=><Login {...props}/> }
          />
          <Route 
           path="/home"
           render={()=><Home/>}
           />
      </Router>
  </div>
    );
  }
}


export default App;
