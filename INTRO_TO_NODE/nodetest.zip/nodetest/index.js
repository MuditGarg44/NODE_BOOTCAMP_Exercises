//This file has 3 sections made according to questions. Just uncomment the code written under their suitable titles to execute them. Sample file is also included inside



/* ----------------------SYNC FILE READ MODE------------------------------- */

// const http = require('http');

// const hostname = '127.0.0.1';
// const port = 9000;

// const fs = require('fs');
// const data = fs.readFileSync('./samplefie.txt','utf8');
// const server = http.createServer((req, res) => {
//   res.statusCode = 200;
//   res.setHeader('Content-Type', 'text/plain');
//   res.write(data);
//   res.write("FILE READ MODE IS SYNC")
//   res.end();
// });

// server.listen(port, hostname, () => {
//   console.log(`Server running at http://${hostname}:${port}/`);
// });


/* *******************ASYNC FILE READ**************************** */


// const http = require('http');

// const hostname = '127.0.0.1';
// const port = 9000;

// const fs = require('fs');

// const server = http.createServer((req, res) => {
//   res.statusCode = 200;
//   res.setHeader('Content-Type', 'text/plain');
//   const data = fs.readFile('./samplefile.txt', (err,data)=>{
//     if(err) {
//         throw err;}
//     else {
//     res.write(data.toString());
//     }
//     res.write("FILE READ MODE IS ASYNC, but since data is too short, hence it is read add printed quick and this lines is printed at last position");
//     res.end();
//  });

// });



// server.listen(port, hostname, () => {
//   console.log(`Server running at http://${hostname}:${port}/`);
// });


/* -------------------MODULE IMPORT AND EXPORT----------------------- */

// const http = require('http');

// const hostname = '127.0.0.1';
// const port = 9000;

// const fs = require('fs');
//  const Area = require('./calculations.js');
// console.log("This is 2nd console command but running 1st.");
// const server = http.createServer((req, res) => {
//   res.statusCode = 200;
//   res.setHeader('Content-Type', 'text/plain');
//   res.end(`area is  ${Area.area(5,10)} `);

// });



// server.listen(port, hostname, () => {
//   console.log(`Server running at http://${hostname}:${port}/`);
// });