exports.area =(l,b) =>
{
    return l*b;
}